#!/usr/bin/env python3
"""Claude Skills Library CLI - validate, analyze, and manage skills.

The same ``SKILL.md`` format works across AI agents (Claude Code, OpenCode,
Cursor, Windsurf, etc.) thanks to the universal Agent Skills file layout.
"""

from __future__ import annotations

import json as json_lib
import time
from pathlib import Path
from typing import Any

import click
from colorama import Fore, Style  # type: ignore[import-untyped]

from claude_skills import ensure_utf8_console
from claude_skills.catalog import CatalogBuilder, canonical_skill_path
from claude_skills.models import QualityScore, SkillFile, ValidationResult, parse_frontmatter
from claude_skills.quality import QualityAnalyzer, QualityReport
from claude_skills.validator import ValidationPipeline

DEFAULT_SKILLS = ".claude/skills"
REGISTRY_URL = "https://ssrjkk.github.io/agent-skills/skills_catalog.json"


def score_entry(entry: dict[str, Any], query: str) -> int:
    """Simple relevance score shared by local and remote search (0 = no match)."""
    q = query.lower()
    score = 0
    if q in entry["name"].lower():
        score += 50
    if q in entry["description"].lower():
        score += 25
    if any(q in tag.lower() for tag in entry["tags"]):
        score += 10
    return score


def fetch_remote_catalog(url: str = REGISTRY_URL) -> list[dict[str, Any]]:
    """Download the published registry (catalog.json) and return its skill entries."""
    import urllib.error
    import urllib.request

    request = urllib.request.Request(url, headers={"User-Agent": "agent-skills-cli"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json_lib.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError) as exc:
        raise click.ClickException(f"registry unavailable ({url}): {exc}") from exc
    entries = payload.get("skills") if isinstance(payload, dict) else payload
    if not isinstance(entries, list) or not all(isinstance(e, dict) for e in entries):
        raise click.ClickException(f"unexpected registry payload ({url})")
    return entries


def resolve_skills_dir(dir_value: str | None) -> str:
    if dir_value is None:
        return DEFAULT_SKILLS
    path = Path(dir_value)
    if not path.is_dir():
        raise click.ClickException(f"Skills directory not found: {path}")
    return str(path)


@click.group()
def cli() -> None:
    """Claude Skills Library CLI v4.1.1 - Production Ready."""
    ensure_utf8_console()


@cli.command()
@click.option('--dir', type=click.Path(), default=None, help=f'Skills dir (default: {DEFAULT_SKILLS})')
@click.option('--json', '--output', 'json', type=click.Path(), help='Output JSON report')
def stats(dir: str | None, json: str | None) -> None:
    """Show library statistics."""
    start = time.perf_counter()

    builder = CatalogBuilder(base=resolve_skills_dir(dir))
    catalog = builder.build_catalog()

    print(f"\n{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}Claude Skills Library - Statistics{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")

    print(f"  Total skills: {Fore.YELLOW}{catalog.metadata.total_skills}{Style.RESET_ALL}")
    print(f"  Bilingual coverage: {Fore.YELLOW}{catalog.metadata.total_ru}/{catalog.metadata.total_skills}{Style.RESET_ALL}")
    print(f"  Domains: {Fore.YELLOW}{len(catalog.metadata.domains)}{Style.RESET_ALL}")
    print(f"  Schema version: {Fore.YELLOW}v{catalog.metadata.schema_version}{Style.RESET_ALL}")

    duration = time.perf_counter() - start
    print(f"\n    Completed in {Fore.CYAN}{duration:.2f}s{Style.RESET_ALL}\n")

    if json:
        report = {
            "total_skills": catalog.metadata.total_skills,
            "total_ru": catalog.metadata.total_ru,
            "domains": catalog.metadata.domains,
            "schema_version": catalog.metadata.schema_version,
        }
        Path(json).write_text(json_lib.dumps(report, indent=2), encoding="utf-8")
        print(f"   Report saved to {Fore.CYAN}{json}{Style.RESET_ALL}\n")


@cli.command()
@click.option('--dir', type=click.Path(), default=None, help=f'Skills dir (default: {DEFAULT_SKILLS})')
@click.option('--json', '--output', 'json', type=click.Path(), help='Output JSON report')
def validate(dir: str | None, json: str | None) -> None:
    """Validate all skills (EN + RU)."""
    start = time.perf_counter()

    skills_dir = resolve_skills_dir(dir)
    pipeline = ValidationPipeline(Path(skills_dir))
    en_results = pipeline.run_all()
    ru_results = pipeline.run_ru_all()

    combined: dict[str, list[ValidationResult]] = {}
    for name, results in en_results.items():
        combined[name] = list(results)
    for name, results in ru_results.items():
        combined.setdefault(name, []).extend(results)

    report = pipeline.report(combined)
    # total counts skills (EN files); RU-only leftovers merge into details
    # but must not inflate the skill count
    report["total"] = len(en_results)

    print(f"\n{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}Validation Report{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")

    print(f"  Total skills: {Fore.YELLOW}{report['total']}{Style.RESET_ALL}")
    print(f"  {Fore.RED}Errors: {report['errors']}{Style.RESET_ALL}")
    print(f"  {Fore.YELLOW}Warnings: {report['warnings']}{Style.RESET_ALL}")
    print(f"  {Fore.BLUE}Info: {report['info']}{Style.RESET_ALL}")

    if report['error_details']:
        print(f"\n  {Fore.RED}Top errors:{Style.RESET_ALL}")
        for error in report['error_details'][:5]:
            print(f"    {error}")

    duration = time.perf_counter() - start
    print(f"\n    Completed in {Fore.CYAN}{duration:.2f}s{Style.RESET_ALL}\n")

    if json:
        Path(json).write_text(json_lib.dumps(report, indent=2), encoding="utf-8")
        print(f"   Report saved to {Fore.CYAN}{json}{Style.RESET_ALL}\n")


@cli.command()
@click.option('--dir', type=click.Path(), default=None, help=f'Skills dir (default: {DEFAULT_SKILLS})')
@click.option('--json', '--output', 'json', type=click.Path(), help='Output JSON report')
@click.option('--top', type=int, default=10, help='Show top N skills')
def quality(dir: str | None, json: str | None, top: int) -> None:
    """Analyze quality of all skills."""
    if top <= 0:
        raise click.ClickException("--top must be > 0")
    start = time.perf_counter()

    builder = CatalogBuilder(base=resolve_skills_dir(dir))
    catalog = builder.build_catalog()
    analyzer = QualityAnalyzer()

    scores: dict[str, QualityScore] = {}
    skills_detail: list[dict[str, Any]] = []
    skipped: list[str] = []
    for skill in catalog.skills:
        en_path = skill.path
        ru_path = en_path.parent / "SKILL.ru.md"
        try:
            en_raw = en_path.read_text(encoding="utf-8")
            ru_raw = ru_path.read_text(encoding="utf-8") if ru_path.exists() else ""
        except (OSError, UnicodeDecodeError):
            skipped.append(skill.name)
            continue

        fm_en, body_en, ok_en = parse_frontmatter(en_raw)
        fm_ru, body_ru, _ = parse_frontmatter(ru_raw)
        if not ok_en:  # pragma: no cover - catalog.scan() already filters these
            continue

        sf = SkillFile(
            en_path=en_path,
            ru_path=ru_path if skill.has_ru else None,
            en_content=en_raw,
            ru_content=ru_raw,
            en_frontmatter=fm_en or {},
            ru_frontmatter=fm_ru or {},
            en_body=body_en,
            ru_body=body_ru,
        )
        score = analyzer.analyze(sf)
        scores[skill.name] = score
        skills_detail.append({
            "name": skill.name,
            "category": skill.category,
            "path": str(skill.path.as_posix()),
            "score": round(score.overall, 2),
            "completeness": round(score.completeness, 2),
            "depth": round(score.depth, 2),
            "code_quality": round(score.code_quality, 2),
            "freshness": round(score.freshness, 2),
            "bilingual": round(score.bilingual, 2),
            "has_ru": skill.has_ru,
        })

    report = QualityReport(scores)
    avg = report.average

    print(f"\n{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}Quality Report{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")

    print(f"  Skills analyzed: {Fore.YELLOW}{len(scores)}{Style.RESET_ALL}")
    if skipped:
        print(f"  {Fore.RED}Skipped unreadable: {', '.join(sorted(skipped))}{Style.RESET_ALL}")
    print(f"  Average completeness: {Fore.YELLOW}{avg.completeness:.1f}%{Style.RESET_ALL}")
    print(f"  Average depth:        {Fore.YELLOW}{avg.depth:.1f}%{Style.RESET_ALL}")
    print(f"  Average code quality: {Fore.YELLOW}{avg.code_quality:.1f}%{Style.RESET_ALL}")
    print(f"  Average freshness:    {Fore.YELLOW}{avg.freshness:.1f}%{Style.RESET_ALL}")
    print(f"  Average bilingual:    {Fore.YELLOW}{avg.bilingual:.1f}%{Style.RESET_ALL}")
    print(f"\n  Overall score: {Fore.GREEN}{avg.overall:.1f}%{Style.RESET_ALL}\n")

    print(f"\n   Top {top} skills:")
    for i, (name, score) in enumerate(report.top_skills(top), 1):
        print(f"    {i}. {Fore.CYAN}{name}{Style.RESET_ALL} - {score.overall:.1f}%")

    duration = time.perf_counter() - start
    print(f"\n    Completed in {Fore.CYAN}{duration:.2f}s{Style.RESET_ALL}\n")

    if json:
        data = {
            "average": {
                "completeness": avg.completeness,
                "depth": avg.depth,
                "code_quality": avg.code_quality,
                "freshness": avg.freshness,
                "bilingual": avg.bilingual,
                "overall": avg.overall,
            },
            "total_skills": len(scores),
            "skills": skills_detail,
        }
        Path(json).write_text(json_lib.dumps(data, indent=2), encoding="utf-8")
        print(f"   Report saved to {Fore.CYAN}{json}{Style.RESET_ALL}\n")


@cli.command()
@click.argument('query')
@click.option('--dir', type=click.Path(), default=None, help=f'Skills dir (default: {DEFAULT_SKILLS})')
@click.option('--domain', help='Filter by domain')
@click.option('--limit', type=int, default=10, help='Max results')
@click.option('--remote', is_flag=True, help='Search the published online registry (skills_catalog.json) instead of local files')
def search(query: str, dir: str | None, domain: str | None, limit: int, remote: bool) -> None:
    """Search skills."""
    if not query.strip():
        raise click.ClickException("query must not be empty")
    if limit <= 0:
        raise click.ClickException("--limit must be > 0")
    if remote:
        entries: list[dict[str, Any]] = fetch_remote_catalog()
    else:
        builder = CatalogBuilder(base=resolve_skills_dir(dir))
        catalog = builder.build_catalog()
        entries = [
            {
                "name": s.name,
                "description": s.description,
                "category": s.category,
                "tags": s.tags,
                "languages": s.languages,
                "path": s.path,
            }
            for s in catalog.skills
        ]

    print(f"\n{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}Search Results for: {query}{Style.RESET_ALL}")
    if remote:
        print(f"{Fore.CYAN}source: {REGISTRY_URL}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")

    results = []
    for entry in entries:
        score = score_entry(entry, query)
        if score <= 0:
            continue
        if domain and entry["category"] != domain:
            continue
        results.append((entry, score))

    results.sort(key=lambda x: x[1], reverse=True)

    if not results:
        print(f"  {Fore.YELLOW}No skills found matching '{query}'{Style.RESET_ALL}\n")
        return

    for i, (skill, _score) in enumerate(results[:limit], 1):
        print(f"  {i}. {Fore.CYAN}{skill['name']}{Style.RESET_ALL}")
        print(f"     {skill['description'][:60]}...")
        print(f"      {skill['category']} |  {', '.join(skill['languages'])}")
        if remote:
            skill_path = canonical_skill_path(Path(skill["path"]))
            print(f"     {Fore.BLUE}{skill_path}{Style.RESET_ALL}")
        print()


@cli.command()
@click.argument('name')
@click.option('--target', default=None, help='Target agent skills dir (e.g. ~/.claude/skills)')
@click.option('--dir', type=click.Path(), default=None, help='Source skills dir (default: bundled library)')
def install(name: str, target: str | None, dir: str | None) -> None:
    """Install a single skill by name into an agent's skills directory."""
    import shutil

    target_dir = Path(target).expanduser() if target else Path.home() / ".claude" / "skills"

    if dir:
        source_base = Path(dir)
    else:
        source_base = Path(__file__).resolve().parent.parent.parent / ".claude" / "skills"
        if not source_base.is_dir():  # pragma: no cover - bundled library always present in this repo
            source_base = Path.cwd() / ".claude" / "skills"

    found = None
    for sk in sorted(source_base.rglob("SKILL.md")):
        if sk.parent.name == name:
            found = sk.parent
            break

    if not found:
        raise click.ClickException(f"Skill '{name}' not found in {source_base}")

    category = found.parent.name
    dest = target_dir / category / name

    # copy to a temp sibling first, then swap: a failure never leaves
    # a half-written skill behind (the old dest stays intact until rename)
    tmp_dest = dest.parent / (dest.name + ".tmp")
    if tmp_dest.exists():
        shutil.rmtree(tmp_dest)
    try:
        shutil.copytree(found, tmp_dest)
        if dest.exists():
            print(f"{Fore.YELLOW}Skill '{name}' already exists at {dest}, overwriting...{Style.RESET_ALL}")
            shutil.rmtree(dest)
        tmp_dest.rename(dest)
    except Exception:
        if tmp_dest.exists():
            shutil.rmtree(tmp_dest)
        raise

    file_count = sum(1 for _ in dest.glob("SKILL*.md"))
    print(f"\n{Fore.GREEN}Installed '{name}' -> {dest}{Style.RESET_ALL}")
    print(f"  Files: {file_count}")
    print(f"  Agent: {target_dir}\n")


@cli.command()
@click.option('--dir', type=click.Path(), default=None, help=f'Skills dir (default: {DEFAULT_SKILLS})')
@click.option('--output', type=click.Path(), default='skills_catalog.json', help='Output catalog path')
def catalog(dir: str | None, output: str) -> None:
    """Regenerate catalog."""
    start = time.perf_counter()

    builder = CatalogBuilder(base=resolve_skills_dir(dir))
    cat = builder.build_catalog()
    builder.to_json(cat, path=Path(output))

    duration = time.perf_counter() - start

    print(f"\n{Fore.GREEN}Catalog regenerated{Style.RESET_ALL}")
    print(f"  Skills: {cat.metadata.total_skills}")
    for rel in builder.skipped:
        print(f"  {Fore.RED}Skipped unparseable: {rel}{Style.RESET_ALL}")
    for dup in builder.duplicates:
        print(f"  {Fore.YELLOW}Duplicate name (first kept): {dup}{Style.RESET_ALL}")
    print(f"  Time: {duration:.2f}s\n")


@cli.command()
@click.option('--dir', type=click.Path(), default=None, help=f'Skills dir (default: {DEFAULT_SKILLS})')
@click.option('--days', type=int, default=180, help='Flag skills not updated within N days')
def stale(dir: str | None, days: int) -> None:
    """List skills whose `updated` date is older than N days (review queue)."""
    if days <= 0:
        raise click.ClickException("--days must be > 0")
    import datetime

    builder = CatalogBuilder(base=resolve_skills_dir(dir))
    catalog = builder.build_catalog()
    today = datetime.datetime.now(tz=datetime.timezone.utc).date()

    rows = []
    for skill in sorted(catalog.skills, key=lambda s: s.updated or ""):
        if not skill.updated:
            rows.append((skill.name, skill.category, "never", -1))
            continue
        # same parsing as QualityAnalyzer._score_freshness: date-only,
        # datetime, and trailing-Z stamps are all accepted
        stamp = skill.updated
        stamp = stamp.replace("Z", "+00:00") if stamp.endswith(("Z", "z")) else stamp
        try:
            age = (today - datetime.datetime.fromisoformat(stamp).date()).days
        except (ValueError, TypeError):
            rows.append((skill.name, skill.category, skill.updated, -1))
            continue
        if age > days:
            rows.append((skill.name, skill.category, skill.updated, age))

    print(f"\n{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}Stale skills (>{days}d without update){Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}\n")

    if not rows:
        print(f"  {Fore.GREEN}Nothing stale - all {len(catalog.skills)} skills updated within {days} days{Style.RESET_ALL}\n")
        return

    for name, category, updated, age in rows:
        age_str = f"{age}d" if age >= 0 else "unknown date"
        print(f"  {Fore.YELLOW}{name}{Style.RESET_ALL} ({category}) - {updated} [{age_str}]")
    print()


if __name__ == '__main__':  # pragma: no cover
    cli()
