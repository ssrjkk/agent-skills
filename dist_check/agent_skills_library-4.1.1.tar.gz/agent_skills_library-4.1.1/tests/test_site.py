"""Tests for the docs site generator (build_docs.py)."""

from __future__ import annotations

import json
import re
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import pytest

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"


class _ScriptExtractor(HTMLParser):
    """Collect inline <script> bodies without regex tag filtering
    (regex-based tag matching trips CodeQL py/bad-tag-filter)."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.blocks: list[str] = []
        self._buf: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "script":
            return
        attrs_dict = dict(attrs)
        if "src" in attrs_dict:
            return
        script_type = (attrs_dict.get("type") or "text/javascript").lower()
        if script_type not in ("text/javascript", "module"):
            return
        self._buf = []

    def handle_data(self, data: str) -> None:
        if self._buf is not None:
            self._buf.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._buf is not None:
            self.blocks.append("".join(self._buf))
            self._buf = None


def _inline_scripts(html: str) -> list[str]:
    parser = _ScriptExtractor()
    parser.feed(html)
    return parser.blocks


def _make_skill(root: Path, name: str, category: str, description: str = "A test skill") -> Path:
    skill_dir = root / ".claude" / "skills" / category / name
    skill_dir.mkdir(parents=True)
    body = (
        "---\n"
        f"name: {name}\n"
        f"description: {description}\n"
        f"category: {category}\n"
        "tags: [testing, automation]\n"
        "models: [sonnet, opus]\n"
        "version: 1.0.0\n"
        "created: 2026-09-01\n"
        "updated: 2026-09-28\n"
        "---\n# Skill\n"
        "## Quick Start\n```python\nprint('hi')\n```\n"
        "## When to Use\n- when needed\n"
        "## Step-by-Step\n1. do it\n"
        "## Examples\n```python\nx = 1\n```\n"
        "## Validation\nrun tests\n"
        "## Best Practices\n- keep it simple\n"
        "## Troubleshooting\n- if broken fix\n"
    )
    (skill_dir / "SKILL.md").write_text(body, encoding="utf-8")
    (skill_dir / "SKILL.ru.md").write_text(
        body.replace("Quick Start", "Быстрый старт").replace("When to Use", "Когда использовать"),
        encoding="utf-8",
    )
    return skill_dir


def _build_site(tmp_path: Path) -> Path:
    """Build a full docs site from a temporary catalog and skills tree."""
    _make_skill(tmp_path, "alpha", "backend")
    _make_skill(tmp_path, "beta", "frontend")
    catalog = {
        "metadata": {
            "schema_version": "3.0",
            "generated_at": "2026-09-28T00:00:00Z",
            "total_skills": 2,
            "total_ru": 2,
            "domains": ["backend", "frontend"],
            "bilingual": True,
        },
        "skills": [
            {
                "name": "alpha",
                "description": "A test backend skill",
                "category": "backend",
                "tags": ["api", "python"],
                "models": ["sonnet", "opus"],
                "version": "1.0.0",
                "path": str(tmp_path / ".claude" / "skills" / "backend" / "alpha" / "SKILL.md"),
                "languages": ["en", "ru"],
                "has_ru": True,
                "created": "2026-09-01",
                "updated": "2026-09-28",
            },
            {
                "name": "beta",
                "description": "A test frontend skill",
                "category": "frontend",
                "tags": ["react", "ts"],
                "models": ["sonnet", "opus"],
                "version": "1.0.0",
                "path": str(tmp_path / ".claude" / "skills" / "frontend" / "beta" / "SKILL.md"),
                "languages": ["en", "ru"],
                "has_ru": True,
                "created": "2026-09-01",
                "updated": "2026-09-28",
            },
        ],
    }
    catalog_path = tmp_path / "skills_catalog.json"
    catalog_path.write_text(json.dumps(catalog), encoding="utf-8")

    rm_dir = tmp_path / "roadmaps"
    rm_dir.mkdir(parents=True, exist_ok=True)
    (rm_dir / "frontend.json").write_text(json.dumps({
        "slug": "frontend", "name": "Frontend", "icon": "🖥️",
        "tagline": "React, CSS, UI engineering", "status": "soon", "eta": "soon",
        "catalog_domain": "frontend", "related_skills": ["beta"],
        "stages": [{"title": "Fundamentals", "items": ["Map drops soon"], "status": "soon"}],
    }), encoding="utf-8")
    (rm_dir / "design.json").write_text(json.dumps({
        "slug": "design", "name": "Design", "icon": "🎨",
        "tagline": "Specs and diagrams", "status": "soon", "eta": "soon",
        "catalog_domain": None, "related_skills": [],
        "stages": [{"title": "Fundamentals", "items": ["Map drops soon"], "status": "soon"}],
    }), encoding="utf-8")

    guides_dir = rm_dir / "guides"
    guides_dir.mkdir(parents=True, exist_ok=True)
    (guides_dir / "Resume_Sergey_Sitnikov_DevOps_2026.md").write_text(
        "# Resume\n\nDevOps / Platform Engineer.\n",
        encoding="utf-8",
    )
    (guides_dir / "00_README.md").write_text(
        "# Полный сборник мап\n\nДайджест всех карт и артефактов.\n",
        encoding="utf-8",
    )
    (guides_dir / "21_Linux_Map.md").write_text(
        "# Карта 21: Linux и Сети\n\nПервая строка описания карты.\n\n"
        "| Команда | Зачем |\n|---|---|\n| `uptime` | load average |\n\n"
        "- [x] сделано\n- [ ] не сделано\n\n**Жирный тезис** и `код`.\n",
        encoding="utf-8",
    )
    (guides_dir / "22_Vibe_Map.md").write_text(
        "# Карта 22: Вайбкодинг\n\nSEO и SSR для витрин.\n\n"
        "- пункт один\n- пункт два\n\n[GitHub](https://github.com/ssrjkk/agent-skills)\n",
        encoding="utf-8",
    )

    mod = _load_mod()

    out = tmp_path / "docs"
    out.mkdir(parents=True, exist_ok=True)
    (out / "skills").mkdir(parents=True, exist_ok=True)
    (out / "domains").mkdir(parents=True, exist_ok=True)
    mod.build_index_html(catalog_path, out)
    mod.build_skill_pages(catalog_path, out)
    mod.build_domain_pages(catalog_path, out)
    mod.build_roadmaps(out, source_dir=tmp_path)
    mod.build_guides(out, source_dir=tmp_path)
    mod.build_hire(out, source_dir=tmp_path)
    mod.build_style_css(out)
    mod.build_site_js(out)
    mod.build_search_index(catalog_path, out)
    return out

def _load_mod() -> Any:
    import importlib.util

    spec = importlib.util.spec_from_file_location("build_docs", SCRIPTS / "build_docs.py")
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _write_catalog(tmp_path: Path, skills: list[dict[str, Any]]) -> Path:
    catalog = {
        "metadata": {
            "schema_version": "3.0",
            "generated_at": "2026-09-28T00:00:00Z",
            "total_skills": len(skills),
            "total_ru": sum(1 for s in skills if s.get("has_ru")),
            "domains": sorted({s["category"] for s in skills}),
            "bilingual": True,
        },
        "skills": skills,
    }
    catalog_path = tmp_path / "skills_catalog.json"
    catalog_path.write_text(json.dumps(catalog), encoding="utf-8")
    return catalog_path


def _skill_entry(tmp_path: Path, name: str, category: str) -> dict[str, Any]:
    return {
        "name": name,
        "description": f"A test {category} skill",
        "category": category,
        "tags": ["testing"],
        "models": ["sonnet"],
        "version": "1.0.0",
        "path": str(tmp_path / ".claude" / "skills" / category / name / "SKILL.md"),
        "languages": ["en", "ru"],
        "has_ru": True,
        "created": "2026-09-01",
        "updated": "2026-09-28",
    }


class TestSiteGenerator:
    def test_all_pages_generated(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        assert (docs / "index.html").exists()
        assert (docs / "search-index.json").exists()
        assert (docs / "style.css").exists()
        assert (docs / "skills" / "alpha.html").exists()
        assert (docs / "skills" / "beta.html").exists()
        assert (docs / "domains" / "backend.html").exists()
        assert (docs / "domains" / "frontend.html").exists()

    def test_css_paths_correct(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'href="style.css"' in index, "index must use style.css"
        skill = (docs / "skills" / "alpha.html").read_text(encoding="utf-8")
        assert 'href="../style.css"' in skill, "skill page must use ../style.css"
        domain = (docs / "domains" / "backend.html").read_text(encoding="utf-8")
        assert 'href="../style.css"' in domain, "domain page must use ../style.css"

    def test_search_index_has_all_skills(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        idx = json.loads((docs / "search-index.json").read_text(encoding="utf-8"))
        names = {e["name"] for e in idx}
        assert names == {"alpha", "beta"}
        alpha = next(e for e in idx if e["name"] == "alpha")
        assert "quick start" in alpha["content"]
        assert "validation" in alpha["content"]
        assert "быстрый старт" in alpha["content_ru"]

    def test_skill_page_has_ru_toggle(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        html = (docs / "skills" / "alpha.html").read_text(encoding="utf-8")
        assert "showSkillLang" in html
        assert 'data-slang-body="en"' in html
        assert 'data-slang-body="ru"' in html
        assert "Быстрый старт" in html

    def test_skill_page_without_ru_has_no_toggle(self, tmp_path: Path):
        mod = _load_mod()
        skill_dir = _make_skill(tmp_path, "solo", "backend")
        (skill_dir / "SKILL.ru.md").unlink()
        catalog_path = _write_catalog(tmp_path, [_skill_entry(tmp_path, "solo", "backend")])
        out = tmp_path / "docs"
        (out / "skills").mkdir(parents=True)
        assert mod.build_skill_pages(catalog_path, out) == 1
        html = (out / "skills" / "solo.html").read_text(encoding="utf-8")
        assert "lang-tabs" not in html
        assert 'data-slang-body="en"' not in html
        assert "Quick Start" in html

    def test_no_broken_relative_links(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        for page in docs.rglob("*.html"):
            html = page.read_text(encoding="utf-8")
            for m in re.finditer(r'href="([^"]+\.html)"', html):
                href = m.group(1)
                if href.startswith(("http", "//", "#")):
                    continue
                target = (page.parent / href).resolve()
                assert target.exists(), f"{page.name} -> broken link {href}"

    def test_roadmaps_standalone(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        assert (docs / "roadmaps.html").exists()
        assert (docs / "roadmaps.json").exists()
        rm_dir = docs / "roadmaps"
        assert rm_dir.is_dir()
        pages = list(rm_dir.glob("*.html"))
        assert len(pages) >= 1, "each roadmap track needs its own page"
        data = json.loads((docs / "roadmaps.json").read_text(encoding="utf-8"))
        slugs = {t["slug"] for t in data["tracks"]}
        assert slugs, "roadmaps.json must list tracks"
        for slug in slugs:
            assert (rm_dir / f"{slug}.html").exists(), f"missing roadmap page: {slug}"
        for track in data["tracks"]:
            assert track["status"] in {"soon", "live"}
            assert len(track["stages"]) >= 1

    def test_bilingual_track_pages_render_mirror(self, tmp_path: Path):
        tracks = tmp_path / "roadmaps"
        tracks.mkdir(exist_ok=True)
        (tracks / "qa.json").write_text(json.dumps({
            "slug": "qa", "name": "QA", "name_ru": "QA / SDET", "icon": "🧪",
            "tagline": "Test design to SDET", "tagline_ru": "От тест-дизайна до SDET",
            "status": "live", "eta": "2026-11", "catalog_domain": "frontend", "related_skills": ["beta"],
            "stages": [{
                "title": "Stage 0. Foundations", "title_ru": "Этап 0. Основы",
                "items": ["equivalence classes", "bug reports"],
                "items_ru": ["классы эквивалентности", "баг-репорты"],
                "status": "live",
            }],
        }), encoding="utf-8")
        mod = _load_mod()
        out = tmp_path / "docs"
        out.mkdir()
        mod.build_roadmaps(out, source_dir=tmp_path)
        page = (out / "roadmaps" / "qa.html").read_text(encoding="utf-8")
        assert '<span data-slang-body="en">QA</span><span data-slang-body="ru" hidden>QA / SDET</span>' in page
        assert '<span data-slang-body="ru" hidden>Этап 0. Основы</span>' in page
        assert '<ul data-slang-body="ru" hidden>' in page
        assert "классы эквивалентности" in page
        overview = (out / "roadmaps.html").read_text(encoding="utf-8")
        assert "items_ru" in overview  # RM_DATA carries the RU mirror for client re-render
        assert "refreshTrack" in overview
        assert "· 1 live" in overview  # honest hero badge per build
        assert 'data-live="1" data-total="0"' in overview

    def test_stub_track_pages_stay_monolingual(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "roadmaps" / "frontend.html").read_text(encoding="utf-8")
        assert '<ul data-slang' not in page, "no RU mirror until the track JSON ships one"
        assert "Map drops soon" in page

    def test_hero_counts_reflect_track_statuses(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'data-live="0" data-total="2"' in index  # fixture tracks: frontend + design, both soon
        rm = (docs / "roadmaps.html").read_text(encoding="utf-8")
        assert "· 0 live" in rm

    def test_i18n_keys_cover_markup(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        pages = (
            list(docs.glob("*.html"))
            + list((docs / "skills").glob("alpha.html"))
            + list((docs / "domains").glob("*.html"))
            + list((docs / "roadmaps").glob("*.html"))
            + list((docs / "guides").glob("*.html"))
        )
        assert len(pages) >= 6
        used: set[str] = set()
        for page in pages:
            html = page.read_text(encoding="utf-8")
            used.update(re.findall(r'data-i18n="([a-z_0-9]+)"', html))
            used.update(re.findall(r'data-i18n-ph="([a-z_0-9]+)"', html))
            used.update(re.findall(r'data-i18n-aria="([a-z_0-9]+)"', html))
        assert used, "expected i18n hooks in markup"
        # single source of truth: every key must be defined in assets/site.js
        site_js = (docs / "site.js").read_text(encoding="utf-8")
        for key in sorted(used):
            assert f'{key}:"' in site_js, f"key {key!r} missing in site.js dicts"

    def test_i18n_single_source_of_truth(self):
        src = (SCRIPTS / "build_docs.py").read_text(encoding="utf-8")
        assert src.count("var I18N = {") == 0, "I18N dict must live in assets/site.js, not inline"
        site_js = (ROOT / "assets" / "site.js").read_text(encoding="utf-8")
        head, sep, tail = site_js.partition("\n    ru: ")
        assert sep, "no ru dict in site.js"
        key_re = re.compile(r"[{,]\s*([A-Za-z_][A-Za-z_0-9]*)\s*:\"")
        en_keys = set(key_re.findall(head))
        ru_keys = set(key_re.findall(tail))
        assert en_keys, "no en keys parsed"
        assert en_keys == ru_keys, f"en/ru drift: {sorted(en_keys ^ ru_keys)}"
        assert "hero_sub" in en_keys

    def test_div_tags_balanced(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        for page in docs.rglob("*.html"):
            html = page.read_text(encoding="utf-8")
            assert html.count("<div") == html.count("</div>"), f"unbalanced divs in {page.name}"

    def test_theme_toggle_and_search_js_present(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert "toggleTheme" in index
        assert "loadSearchIndex" in index
        assert "filterByDomain" in index
        assert "applyFilter" in index

    def test_shared_site_js_single_source(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        src = (ROOT / "assets" / "site.js").read_text(encoding="utf-8")
        for fn in ["setLang", "toggleTheme", "showSkillLang", "copyBtn",
                   "showToast", "toggleLang", "IntersectionObserver"]:
            assert fn in src, f"assets/site.js missing {fn}"
        built = (docs / "site.js").read_text(encoding="utf-8")
        assert built == src, "docs/site.js must be an exact copy of assets/site.js"
        for page in list(docs.glob("*.html")) + list((docs / "skills").glob("*.html")):
            html = page.read_text(encoding="utf-8")
            assert "var I18N" not in html, f"{page.name} duplicates shared JS"

    def test_tabbed_layout_present(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert "showTab" in index
        for tab in ["catalog", "roadmaps", "guides", "stats", "how", "install"]:
            assert f'data-panel="{tab}"' in index, f"missing tab panel: {tab}"
            assert f"showTab('{tab}'" in index, f"missing tab button: {tab}"
        assert index.count("tab-panel active") >= 2  # search + results in catalog

    def test_i18n_and_delights_present(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'src="site.js"' in index  # shared behavior, not inline
        assert "toggleLang" in index or "lang-toggle" in index
        assert 'data-i18n="hero_sub"' in index
        assert 'data-i18n-ph="search_ph"' in index
        assert 'id="result-count"' in index
        assert 'id="back-top"' in index
        assert "copyBtn" in index
        assert "card-copy" in index
        assert "<kbd>/</kbd>" in index
        skill = (docs / "skills" / "alpha.html").read_text(encoding="utf-8")
        assert 'src="../site.js"' in skill  # shared script, no inline copy
        assert 'data-i18n="quality"' in skill
        assert ".claude/skills/backend/alpha" in skill  # full copy path, not bare name
        rm = (docs / "roadmaps.html").read_text(encoding="utf-8")
        assert 'data-i18n="rm_t"' in rm

    def test_light_theme_css_present(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        css = (docs / "style.css").read_text(encoding="utf-8")
        assert 'data-theme="light"' in css, "light theme must be defined"

    def test_check_site_consistency_script(self, tmp_path: Path):
        # Build into real docs layout and run the consistency script against it
        docs = _build_site(tmp_path)
        # write catalog to the docs parent as the script expects ROOT-based paths
        # Instead, run the script's logic manually on the generated docs
        idx = json.loads((docs / "search-index.json").read_text(encoding="utf-8"))
        assert len(idx) == 2
        for page in docs.rglob("*.html"):
            assert page.read_text(encoding="utf-8").count("<div") == page.read_text(encoding="utf-8").count("</div>")


class TestBuildRobustness:
    """Graceful degradation: duplicates, missing files, empty inputs."""

    def test_duplicate_skill_names_keep_first(self, tmp_path: Path):
        _make_skill(tmp_path, "alpha", "backend")
        mod = _load_mod()
        catalog_path = _write_catalog(tmp_path, [
            _skill_entry(tmp_path, "alpha", "backend"),
            _skill_entry(tmp_path, "alpha", "backend"),
        ])
        out = tmp_path / "docs"
        (out / "skills").mkdir(parents=True)
        assert mod.build_skill_pages(catalog_path, out) == 1
        assert (out / "skills" / "alpha.html").exists()

    def test_missing_skill_file_degrades(self, tmp_path: Path):
        mod = _load_mod()
        catalog_path = _write_catalog(tmp_path, [
            _skill_entry(tmp_path, "ghost", "backend"),
        ])
        out = tmp_path / "docs"
        (out / "skills").mkdir(parents=True)
        assert mod.build_skill_pages(catalog_path, out) == 1
        assert (out / "skills" / "ghost.html").exists()

    def test_empty_catalog_builds_index(self, tmp_path: Path):
        mod = _load_mod()
        catalog_path = _write_catalog(tmp_path, [])
        out = tmp_path / "docs"
        out.mkdir(parents=True)
        mod.build_index_html(catalog_path, out)
        assert (out / "index.html").exists()

    def test_corrupt_roadmaps_fall_back_to_seed(self, tmp_path: Path):
        mod = _load_mod()
        rm_dir = tmp_path / "roadmaps"
        rm_dir.mkdir(parents=True)
        (rm_dir / "broken.json").write_text("{not json", encoding="utf-8")
        tracks = mod.load_roadmap_tracks(source_dir=tmp_path)
        assert len(tracks) == len(mod.ROADMAP_TRACKS)
        assert all(t["slug"] for t in tracks)

    def test_minify_css_preserves_quoted_strings(self):
        mod = _load_mod()
        out = mod.minify_css('.a::before{content:"> ";color:red} /* x */\n.b{margin:0 auto}')
        assert 'content:"> "' in out
        assert "/*" not in out
        assert "\n" not in out

    def test_no_template_literals_leak_into_scripts(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        for page in list(docs.glob("*.html")) + [docs / "roadmaps.html"]:
            html = page.read_text(encoding="utf-8")
            for block in _inline_scripts(html):
                assert "{json.dumps" not in block
                assert "{esc(" not in block
                assert "{{" not in block
                assert "&quot;" not in block

    def test_inline_js_parses_with_node(self, tmp_path: Path):
        import shutil
        import subprocess

        if shutil.which("node") is None:
            pytest.skip("node not available")
        docs = _build_site(tmp_path)
        blocks = []
        for page in list(docs.glob("*.html")) + [docs / "roadmaps.html"]:
            html = page.read_text(encoding="utf-8")
            blocks.extend(_inline_scripts(html))
        assert blocks, "expected inline scripts"
        bundle = tmp_path / "inline.js"
        bundle.write_text("\n;\n".join(blocks), encoding="utf-8")
        proc = subprocess.run(["node", "--check", str(bundle)], check=False, capture_output=True, text=True)
        assert proc.returncode == 0, proc.stderr[:2000]

    def test_index_js_runs_in_stubbed_dom(self, tmp_path: Path):
        """Execute the index inline script against DOM stubs: catches
        ReferenceErrors (the dead-script bug class), not just syntax."""
        import shutil
        import subprocess

        if shutil.which("node") is None:
            pytest.skip("node not available")
        docs = _build_site(tmp_path)
        html = (docs / "index.html").read_text(encoding="utf-8")
        blocks = _inline_scripts(html)
        assert blocks, "expected inline scripts on index"
        harness = tmp_path / "runjs.js"
        harness.write_text(
            "var document = {"
            "querySelectorAll: function() { return []; },"
            "querySelector: function() { return null; },"
            "getElementById: function() { return null; },"
            "addEventListener: function() {},"
            "createElement: function() { return {classList: {add: function() {}}}; },"
            "documentElement: {setAttribute: function() {}}};\n"
            "var window = {addEventListener: function() {}, scrollTo: function() {}};\n"
            "var location = {hash: ''};\n"
            "var navigator = {language: 'en'};\n"
            "var localStorage = {getItem: function() { return null; },"
            " setItem: function() {}, removeItem: function() {}};\n"
            "var sessionStorage = {getItem: function() { return null; }};\n"
            "var history = {replaceState: function() {}};\n"
            "var requestAnimationFrame = function() { return 0; };\n"
            + "\n;\n".join(blocks)
            + "\nconsole.log(JSON.stringify({"
            "scoreHit: scoreSkill('fast', 'fastapi', 'backend', 'fastapi python',"
            " 'fast rest api', 'some body text'),"
            "scoreMiss: scoreSkill('zzz', 'fastapi', 'backend', 'x', 'y', 'z'),"
            "scoreEmpty: scoreSkill('', 'a', 'b', 'c', 'd', 'e'),"
            "scoreMid: scoreSkill('api', 'go-rest-api', 'backend', 'go gin', 'rest', 'x'),"
            "fns: [typeof showTab, typeof applyFilter, typeof onSearch,"
            " typeof filterByDomain, typeof scoreSkill].join(',')}));\n",
            encoding="utf-8",
        )
        proc = subprocess.run(["node", str(harness)], check=False, capture_output=True, text=True)
        assert proc.returncode == 0, proc.stderr[:2000]
        out = json.loads(proc.stdout.strip().splitlines()[-1])
        assert out["scoreHit"] == 85, out
        assert out["scoreMiss"] == 0, out
        assert out["scoreEmpty"] == 0, out
        assert out["scoreMid"] == 30, out
        assert out["fns"] == "function,function,function,function,function", out


class TestGuidesPortal:
    """Full-text maps rendered into the site, cross-linked with tracks."""

    def test_guides_pages_generated(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        assert (docs / "guides.html").exists()
        for stem in ("00_README", "21_Linux_Map", "22_Vibe_Map"):
            assert (docs / "guides" / f"{stem}.html").exists()

    def test_guide_page_renders_tables_tasks_inline(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "guides" / "21_Linux_Map.html").read_text(encoding="utf-8")
        assert '<div class="md-table">' in page
        assert "<th>Команда</th>" in page
        assert '<ul class="task-list">' in page
        assert "<input" in page and " checked" in page
        assert "<strong>Жирный тезис</strong>" in page
        assert "<code>код</code>" in page
        assert page.count("<h1") == 1, "guide H1 must render once (title), body H1 is stripped"

    def test_links_sanitized(self):
        mod = _load_mod()
        html = mod.render_guide_markdown("[x](javascript:alert(1)) and [ok](https://example.com)")
        assert "javascript:" not in html.replace("[x](javascript:alert(1))", "")
        assert 'href="https://example.com"' in html
        assert "[x](javascript:alert(1))" in html, "unsafe target must degrade to plain text"

    def test_track_page_links_full_maps(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "roadmaps" / "frontend.html").read_text(encoding="utf-8")
        assert 'href="../guides/21_Linux_Map.html"' in page
        assert 'href="../guides/22_Vibe_Map.html"' in page
        assert "Full maps" in page
        assert "00_README" not in page, "meta guide has no track, must not appear"

    def test_guide_page_cross_links_track_and_jsonld(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "guides" / "21_Linux_Map.html").read_text(encoding="utf-8")
        assert 'href="../roadmaps/frontend.html"' in page
        assert 'data-i18n="back_guides"' in page
        assert "application/ld+json" in page
        assert "TechArticle" in page
        meta = (docs / "guides" / "00_README.html").read_text(encoding="utf-8")
        assert "../roadmaps/" not in meta

    def test_guides_overview_groups_tiers(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        overview = (docs / "guides.html").read_text(encoding="utf-8")
        assert "Handbook &amp; Index" in overview
        assert "Vibe-Coding &amp; Portal · Maps 21–23" in overview
        assert 'href="guides/22_Vibe_Map.html"' in overview

    def test_nav_and_cta_are_honest(self, tmp_path: Path):
        mod = _load_mod()
        docs = _build_site(tmp_path)  # fixture: every track is soon
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'class="soon-dot"' in index
        assert 'class="live-dot"' not in index
        assert '<span data-i18n="nav_guides">Guides</span> · 4 maps →' in index
        mod.RM_STATE = {"live": 2, "total": 2}
        assert "live-dot" in mod.rm_nav_dot()
        assert "all 2 live" in mod.rm_cta_pill()

    def test_rm_note_switches_when_all_live(self, tmp_path: Path):
        mod = _load_mod()
        tracks = tmp_path / "roadmaps"
        tracks.mkdir(exist_ok=True)
        (tracks / "qa.json").write_text(json.dumps({
            "slug": "qa", "name": "QA", "icon": "🧪",
            "tagline": "Test design", "status": "live", "eta": "2026-11",
            "catalog_domain": None, "related_skills": [],
            "stages": [{"title": "S0", "items": ["a", "b"], "status": "live"}],
        }), encoding="utf-8")
        out = tmp_path / "docs"
        out.mkdir()
        mod.build_roadmaps(out, source_dir=tmp_path)
        overview = (out / "roadmaps.html").read_text(encoding="utf-8")
        assert "Every track is live" in overview
        assert "Want this map first?" not in overview


class TestPortalTabs:
    """Index is the full tabbed portal: roadmaps explorer + guides library."""

    def test_tab_order_and_names(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert "TAB_NAMES = ['catalog', 'roadmaps', 'guides', 'stats', 'how', 'install']" in index
        assert "<kbd>1–6</kbd>" in index

    def test_roadmaps_explorer_embedded_in_index(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert "var RM_DATA" in index
        assert "function showTrack(" in index
        assert "function refreshTrack(" in index
        assert 'id="rm-stages"' in index
        assert 'class="rm-tab' in index
        assert "Map drops soon" in index  # first track pre-rendered server-side

    def test_guides_panel_embedded_in_index(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'data-panel="guides"' in index
        assert 'id="guide-search"' in index
        assert "filterGuides" in index
        assert 'href="guides/21_Linux_Map.html"' in index
        assert "Handbook &amp; Index" in index
        assert "data-title=" in index

    def test_hero_glass_chips(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'class="glass-chip"' in index
        assert "<strong>4</strong> maps" in index
        assert "<strong>0/2</strong> live" in index


class TestHirePage:
    """Career mode: open-to-work landing with evidence grid."""

    def test_hire_page_generated_with_contacts_and_tracks(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "hire.html").read_text(encoding="utf-8")
        assert "ray013lefe@gmail.com" in page
        assert "tel:+79003132487" in page
        assert "Senior Fullstack &amp; Systems Engineer" in page
        assert "amoCRM" in page
        assert page.count("how-card") >= 3

    def test_hire_evidence_links_are_live_artifacts(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "hire.html").read_text(encoding="utf-8")
        assert 'href="https://ssrjkk.github.io/agent-skills/"' in page
        assert 'href="https://pypi.org/project/agent-skills-library/"' in page
        assert 'href="https://github.com/ssrjkk/agent-skills/tree/main/labs/pet_project_app"' in page
        # resume map link resolves within the fixture
        assert 'href="guides/Resume_Sergey_Sitnikov_DevOps_2026.html"' in page
        assert (docs / "guides" / "Resume_Sergey_Sitnikov_DevOps_2026.html").exists()

    def test_hire_person_jsonld(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        page = (docs / "hire.html").read_text(encoding="utf-8")
        assert "application/ld+json" in page
        assert '"@type": "Person"' in page
        assert "Saint Petersburg" in page

    def test_hire_nav_and_cta(self, tmp_path: Path):
        docs = _build_site(tmp_path)
        index = (docs / "index.html").read_text(encoding="utf-8")
        assert 'href="hire.html"' in index
        assert 'data-i18n="hire_cta"' in index
        hire = (docs / "hire.html").read_text(encoding="utf-8")
        assert 'data-i18n="nav_hire"' in hire
        assert 'data-i18n="full_resume"' in hire
