"""Tests for CLI commands."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
import pytest
from click.testing import CliRunner

import claude_skills.cli as cli_mod
from claude_skills.cli import cli


def _strip_ansi(text: str) -> str:
    import re
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


def _make_skill(root: Path, name: str, category: str, description: str = "A test skill", tags: str = "testing, automation") -> Path:
    skill_dir = root / ".claude" / "skills" / category / name
    skill_dir.mkdir(parents=True)
    body = (
        "---\n"
        f"name: {name}\n"
        f"description: {description}\n"
        f"category: {category}\n"
        f"tags: [{tags}]\n"
        "models: [sonnet, opus]\n"
        "version: 1.0.0\n"
        "---\n# Skill\n"
        "## Quick Start\ncode sample\n"
        "## Validation\nrun tests\n"
    )
    (skill_dir / "SKILL.md").write_text(body, encoding="utf-8")
    (skill_dir / "SKILL.ru.md").write_text(body.replace("Quick Start", "Быстрый старт"), encoding="utf-8")
    return skill_dir



class TestCliImport:
    def test_cli_group(self):
        names = sorted(cli.commands.keys())
        assert set(names) == {"stats", "validate", "quality", "search", "catalog", "install", "stale"}

    def test_cli_help(self):
        import subprocess
        import sys
        result = subprocess.run(
            [sys.executable, "-m", "claude_skills.cli", "--help"],
            capture_output=True, text=True, check=False
        )
        assert result.returncode == 0
        for name in ("stats", "validate", "quality", "search", "catalog", "install", "stale"):
            assert name in result.stdout


class TestCommandSearch:
    def test_search_found(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        _make_skill(tmp_path, "my-tester", "qa")
        monkeypatch.chdir(tmp_path)
        result = CliRunner().invoke(cli, ["search", "tester"])
        assert result.exit_code == 0
        assert "my-tester" in result.output

    def test_search_not_found(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.chdir(tmp_path)
        result = CliRunner().invoke(cli, ["search", "zzznotfound"])
        assert result.exit_code == 0
        assert "No skills found" in result.output

    def test_search_with_dir(self, tmp_path: Path):
        _make_skill(tmp_path, "dir-tester", "qa")
        result = CliRunner().invoke(cli, ["search", "tester", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "dir-tester" in result.output

    def test_search_domain_filter(self, tmp_path: Path):
        _make_skill(tmp_path, "domain-hit", "qa")
        _make_skill(tmp_path, "domain-miss", "backend")
        result = CliRunner().invoke(
            cli, ["search", "domain", "--dir", str(tmp_path / ".claude" / "skills"), "--domain", "qa"]
        )
        assert result.exit_code == 0
        assert "domain-hit" in result.output
        assert "domain-miss" not in result.output

    def test_search_ranks_by_description_and_tags(self, tmp_path: Path):
        _make_skill(tmp_path, "desc-skill", "qa", description="contains unique-foo keyword")
        _make_skill(tmp_path, "tag-skill", "qa")
        result = CliRunner().invoke(cli, ["search", "unique-foo", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "desc-skill" in result.output

    def test_search_by_tag(self, tmp_path: Path):
        _make_skill(tmp_path, "tag-matched", "qa", tags="special-tag, x")
        _make_skill(tmp_path, "tag-other", "qa")
        result = CliRunner().invoke(cli, ["search", "special-tag", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "tag-matched" in result.output

    def test_search_empty_query_rejected(self, tmp_path: Path):
        _make_skill(tmp_path, "some-skill", "qa")
        result = CliRunner().invoke(cli, ["search", "   ", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code != 0
        assert "must not be empty" in _strip_ansi(result.output)

    def test_search_negative_limit_rejected(self, tmp_path: Path):
        _make_skill(tmp_path, "some-skill", "qa")
        result = CliRunner().invoke(
            cli, ["search", "skill", "--dir", str(tmp_path / ".claude" / "skills"), "--limit", "-5"]
        )
        assert result.exit_code != 0
        assert "--limit must be > 0" in _strip_ansi(result.output)


class TestCommandCatalog:
    def test_catalog_regenerates(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        _make_skill(tmp_path, "test-skill", "qa")
        monkeypatch.chdir(tmp_path)
        result = CliRunner().invoke(cli, ["catalog"])
        assert result.exit_code == 0
        catalog = json.loads((tmp_path / "skills_catalog.json").read_text(encoding="utf-8"))
        assert catalog["metadata"]["total_skills"] == 1

    def test_catalog_with_missing_skills(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.chdir(tmp_path)
        result = CliRunner().invoke(cli, ["catalog"])
        assert result.exit_code == 0
        catalog = json.loads((tmp_path / "skills_catalog.json").read_text(encoding="utf-8"))
        assert catalog["metadata"]["total_skills"] == 0

    def test_catalog_custom_dir_and_output(self, tmp_path: Path):
        _make_skill(tmp_path, "out-skill", "qa")
        out = tmp_path / "custom_catalog.json"
        result = CliRunner().invoke(
            cli, ["catalog", "--dir", str(tmp_path / ".claude" / "skills"), "--output", str(out)]
        )
        assert result.exit_code == 0
        catalog = json.loads(out.read_text(encoding="utf-8"))
        assert catalog["metadata"]["total_skills"] == 1
        assert catalog["skills"][0]["name"] == "out-skill"

    def test_catalog_reports_skipped_and_duplicates(self, tmp_path: Path):
        _make_skill(tmp_path, "same-name", "ai")
        _make_skill(tmp_path, "same-name", "qa")
        broken = tmp_path / ".claude" / "skills" / "qa" / "broken"
        broken.mkdir(parents=True)
        (broken / "SKILL.md").write_text("# No frontmatter here\n", encoding="utf-8")
        out = tmp_path / "catalog.json"
        result = CliRunner().invoke(
            cli, ["catalog", "--dir", str(tmp_path / ".claude" / "skills"), "--output", str(out)]
        )
        assert result.exit_code == 0
        output = _strip_ansi(result.output)
        assert "Skills: 1" in output
        assert "Skipped unparseable: qa/broken/SKILL.md" in output
        assert "Duplicate name (first kept): same-name (qa/same-name/SKILL.md)" in output


class TestCommandValidate:
    def test_validate_clean_skill(self, tmp_path: Path):
        _make_skill(tmp_path, "ok-skill", "qa")
        result = CliRunner().invoke(cli, ["validate", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        output = _strip_ansi(result.output)
        assert "Total skills: 1" in output
        assert "Errors: 0" in output

    def test_validate_validates_ru_too(self, tmp_path: Path):
        skill_dir = _make_skill(tmp_path, "ru-skill", "qa")
        (skill_dir / "SKILL.ru.md").write_text(
            "---\nname: ru-skill\ndescription: desc-ru\ncategory: qa\n"
            "tags: [test]\nmodels: [sonnet]\nversion: 1.0.0\nlanguage: ru\n---\n# Skill\n"
            "## Быстрый старт\ncode\n## Валидация\nrun\n",
            encoding="utf-8",
        )
        result = CliRunner().invoke(cli, ["validate", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "Errors: 0" in _strip_ansi(result.output)

    def test_validate_json_report(self, tmp_path: Path):
        _make_skill(tmp_path, "json-skill", "qa")
        out = tmp_path / "validate.json"
        result = CliRunner().invoke(
            cli, ["validate", "--dir", str(tmp_path / ".claude" / "skills"), "--json", str(out)]
        )
        assert result.exit_code == 0
        data = json.loads(out.read_text(encoding="utf-8"))
        assert data["errors"] == 0
        assert data["total"] >= 1

    def test_validate_total_counts_en_skills_only(self, tmp_path: Path):
        _make_skill(tmp_path, "en-skill", "qa")
        orphan = tmp_path / ".claude" / "skills" / "qa" / "orphan-ru" / "SKILL.ru.md"
        orphan.parent.mkdir(parents=True)
        orphan.write_text(
            "---\nname: orphan-ru\ndescription: desc\ncategory: qa\n"
            "tags: [test]\nmodels: [sonnet]\nversion: 1.0\n---\n# Тест\n\nПросто перевод без английского оригинала.\n",
            encoding="utf-8",
        )
        result = CliRunner().invoke(cli, ["validate", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "Total skills: 1" in _strip_ansi(result.output)


class TestCommandStats:
    def test_stats(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        _make_skill(tmp_path, "stat-skill", "qa")
        monkeypatch.chdir(tmp_path)
        result = CliRunner().invoke(cli, ["stats"])
        assert result.exit_code == 0
        assert "Total skills: 1" in _strip_ansi(result.output)

    def test_stats_respects_dir(self, tmp_path: Path):
        _make_skill(tmp_path, "dir-skill", "qa")
        result = CliRunner().invoke(cli, ["stats", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "Total skills: 1" in _strip_ansi(result.output)

    def test_stats_json_report(self, tmp_path: Path):
        _make_skill(tmp_path, "json-skill", "qa")
        out = tmp_path / "stats.json"
        result = CliRunner().invoke(cli, ["stats", "--dir", str(tmp_path / ".claude" / "skills"), "--json", str(out)])
        assert result.exit_code == 0
        data = json.loads(out.read_text(encoding="utf-8"))
        assert data["total_skills"] == 1
        assert "domains" in data


class TestCommandStale:
    def _make_dated_skill(self, root: Path, name: str, updated: str) -> None:
        skill_dir = root / ".claude" / "skills" / "qa" / name
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\n"
            f"name: {name}\n"
            "description: A test skill\n"
            "category: qa\n"
            "tags: [testing]\n"
            "models: [sonnet]\n"
            "version: 1.0.0\n"
            f"created: 2026-01-01\n"
            f"updated: {updated}\n"
            "---\n# Skill\n\n## Quick Start\ncode\n\n## Validation\ntests\n",
            encoding="utf-8",
        )

    def test_stale_flags_old_skill(self, tmp_path: Path):
        import datetime

        old = (datetime.datetime.now(tz=datetime.timezone.utc).date() - datetime.timedelta(days=200)).isoformat()
        self._make_dated_skill(tmp_path, "old-skill", old)
        result = CliRunner().invoke(cli, ["stale", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "old-skill" in _strip_ansi(result.output)

    def test_stale_clean_when_fresh(self, tmp_path: Path):
        import datetime

        today = datetime.datetime.now(tz=datetime.timezone.utc).date().isoformat()
        self._make_dated_skill(tmp_path, "fresh-skill", today)
        result = CliRunner().invoke(cli, ["stale", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "Nothing stale" in _strip_ansi(result.output)

    def test_stale_lists_undated(self, tmp_path: Path):
        _make_skill(tmp_path, "nodate-skill", "qa")
        result = CliRunner().invoke(cli, ["stale", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "nodate-skill" in _strip_ansi(result.output)

    def test_stale_accepts_zulu_timestamp(self, tmp_path: Path):
        self._make_dated_skill(tmp_path, "zulu-skill", "2026-09-28T00:00:00Z")
        result = CliRunner().invoke(cli, ["stale", "--dir", str(tmp_path / ".claude" / "skills"), "--days", "30"])
        assert result.exit_code == 0
        output = _strip_ansi(result.output)
        assert "zulu-skill" in output
        assert "unknown date" not in output

    def test_stale_nonpositive_days_rejected(self, tmp_path: Path):
        _make_skill(tmp_path, "any-skill", "qa")
        result = CliRunner().invoke(cli, ["stale", "--dir", str(tmp_path / ".claude" / "skills"), "--days", "0"])
        assert result.exit_code != 0
        assert "--days must be > 0" in _strip_ansi(result.output)

    def test_stale_handles_malformed_date(self, tmp_path: Path):
        self._make_dated_skill(tmp_path, "baddate-skill", "not-a-date")
        result = CliRunner().invoke(cli, ["stale", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "baddate-skill" in _strip_ansi(result.output)
        assert "unknown date" in _strip_ansi(result.output)


class TestCommandQuality:
    def test_quality_json_report(self, tmp_path: Path):
        _make_skill(tmp_path, "quality-skill", "qa")
        out = tmp_path / "quality.json"
        result = CliRunner().invoke(
            cli, ["quality", "--dir", str(tmp_path / ".claude" / "skills"), "--json", str(out)]
        )
        assert result.exit_code == 0
        data = json.loads(out.read_text(encoding="utf-8"))
        assert data["total_skills"] == 1
        assert len(data["skills"]) == 1
        assert data["skills"][0]["name"] == "quality-skill"
        assert "score" in data["skills"][0]

    def test_quality_output_alias(self, tmp_path: Path):
        """--output works as an alias for --json."""
        _make_skill(tmp_path, "alias-skill", "qa")
        out = tmp_path / "quality_alias.json"
        result = CliRunner().invoke(
            cli, ["quality", "--dir", str(tmp_path / ".claude" / "skills"), "--output", str(out)]
        )
        assert result.exit_code == 0
        assert out.exists()
        data = json.loads(out.read_text(encoding="utf-8"))
        assert data["skills"][0]["name"] == "alias-skill"

    def test_quality_nonpositive_top_rejected(self, tmp_path: Path):
        _make_skill(tmp_path, "any-skill", "qa")
        result = CliRunner().invoke(cli, ["quality", "--dir", str(tmp_path / ".claude" / "skills"), "--top", "0"])
        assert result.exit_code != 0
        assert "--top must be > 0" in _strip_ansi(result.output)

    def test_quality_skips_broken_frontmatter(self, tmp_path: Path):
        broken = tmp_path / ".claude" / "skills" / "qa" / "broken"
        broken.mkdir(parents=True)
        (broken / "SKILL.md").write_text("---\nname: {unclosed\n---\n## Quick Start\nx\n", encoding="utf-8")
        result = CliRunner().invoke(cli, ["quality", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        assert "Skills analyzed: 0" in _strip_ansi(result.output)

    def test_quality_skips_file_lost_mid_run(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        _make_skill(tmp_path, "ok-skill", "qa")
        _make_skill(tmp_path, "gone-skill", "qa")
        real_read_text = Path.read_text
        calls = {"n": 0}

        def flaky_read(self: Path, *args: Any, **kwargs: Any) -> str:
            if self.name == "SKILL.md" and "gone-skill" in str(self):
                calls["n"] += 1
                if calls["n"] > 1:  # scan saw it, quality re-read must not crash
                    raise OSError("file locked mid-run")
            return real_read_text(self, *args, **kwargs)

        monkeypatch.setattr(Path, "read_text", flaky_read)
        result = CliRunner().invoke(cli, ["quality", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        output = _strip_ansi(result.output)
        assert "Skills analyzed: 1" in output
        assert "Skipped unreadable: gone-skill" in output


class TestCommandValidateErrors:
    def _write_broken_skill(self, root: Path, name: str) -> Path:
        skill_dir = root / ".claude" / "skills" / "qa" / name
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: wrong-name\ncategory: qa\n---\nshort\n", encoding="utf-8"
        )
        return skill_dir

    def test_validate_reports_errors(self, tmp_path: Path):
        self._write_broken_skill(tmp_path, "broken-skill")
        result = CliRunner().invoke(cli, ["validate", "--dir", str(tmp_path / ".claude" / "skills")])
        assert result.exit_code == 0
        output = _strip_ansi(result.output)
        assert "Errors: 1" in output

    def test_validate_missing_dir_errors(self, tmp_path: Path):
        result = CliRunner().invoke(cli, ["validate", "--dir", str(tmp_path / "nope")])
        assert result.exit_code != 0
        assert "not found" in _strip_ansi(result.output)


class TestCommandInstall:
    def test_install_single_skill(self, tmp_path: Path):
        _make_skill(tmp_path, "install-me", "qa")
        target = tmp_path / "target" / ".claude" / "skills"
        result = CliRunner().invoke(
            cli, ["install", "install-me", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code == 0
        assert (target / "qa" / "install-me" / "SKILL.md").exists()

    def test_install_missing_skill(self, tmp_path: Path):
        _make_skill(tmp_path, "other", "qa")
        result = CliRunner().invoke(
            cli, ["install", "ghost", "--target", str(tmp_path / "target"), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code != 0
        assert "not found" in _strip_ansi(result.output)

    def test_install_duplicate_dirname_picks_sorted_first(self, tmp_path: Path):
        _make_skill(tmp_path, "dup", "qa", description="from qa")
        _make_skill(tmp_path, "dup", "ai", description="from ai")
        target = tmp_path / "target" / ".claude" / "skills"
        result = CliRunner().invoke(
            cli, ["install", "dup", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code == 0
        installed = (target / "ai" / "dup" / "SKILL.md").read_text(encoding="utf-8")
        assert "from ai" in installed
        assert not (target / "qa").exists()

    def test_install_leaves_no_tmp_dir(self, tmp_path: Path):
        _make_skill(tmp_path, "clean-me", "qa")
        target = tmp_path / "target" / ".claude" / "skills"
        result = CliRunner().invoke(
            cli, ["install", "clean-me", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code == 0
        assert not (target / "qa" / "clean-me.tmp").exists()

    def test_install_clears_stale_tmp_dir(self, tmp_path: Path):
        _make_skill(tmp_path, "fresh-me", "qa")
        target = tmp_path / "target" / ".claude" / "skills"
        stale_tmp = target / "qa" / "fresh-me.tmp"
        stale_tmp.mkdir(parents=True)
        (stale_tmp / "leftover.txt").write_text("stale", encoding="utf-8")
        result = CliRunner().invoke(
            cli, ["install", "fresh-me", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code == 0
        assert not stale_tmp.exists()
        assert (target / "qa" / "fresh-me" / "SKILL.md").exists()

    def test_install_failure_cleans_tmp_and_raises(self, tmp_path: Path):
        _make_skill(tmp_path, "blocked-me", "qa")
        target = tmp_path / "target" / ".claude" / "skills"
        dest = target / "qa" / "blocked-me"
        dest.parent.mkdir(parents=True)
        dest.write_text("a file blocks the skill directory", encoding="utf-8")
        result = CliRunner().invoke(
            cli, ["install", "blocked-me", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code != 0
        assert not (target / "qa" / "blocked-me.tmp").exists()

    def test_install_overwrites_existing(self, tmp_path: Path):
        _make_skill(tmp_path, "dup", "qa")
        target = tmp_path / "target" / ".claude" / "skills"
        CliRunner().invoke(cli, ["install", "dup", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")])
        # second install overwrites without error
        result = CliRunner().invoke(
            cli, ["install", "dup", "--target", str(target), "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code == 0
        assert "already exists" in _strip_ansi(result.output)

    def test_install_defaults_to_home_claude(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        _make_skill(tmp_path, "default-home", "qa")
        fake_home = tmp_path / "fakehome"
        fake_home.mkdir()
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
        result = CliRunner().invoke(
            cli, ["install", "default-home", "--dir", str(tmp_path / ".claude" / "skills")]
        )
        assert result.exit_code == 0
        assert (fake_home / ".claude" / "skills" / "qa" / "default-home" / "SKILL.md").exists()

    def test_install_not_in_bundled_fails(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        _make_skill(tmp_path, "local-only", "qa")
        monkeypatch.chdir(tmp_path)
        result = CliRunner().invoke(cli, ["install", "local-only", "--target", str(tmp_path / "out")])
        # not in bundled library -> not found without --dir
        assert result.exit_code != 0
        assert "not found" in _strip_ansi(result.output)


def _registry_payload() -> dict[str, Any]:
    return {
        "metadata": {"schema_version": "3.0", "total_skills": 2},
        "skills": [
            {
                "name": "agent-development",
                "description": "Build reliable LLM agents and agentic workflows.",
                "category": "ai",
                "tags": ["agents", "llm"],
                "languages": ["en", "ru"],
                "path": ".claude/skills/ai/agent-development",
            },
            {
                "name": "redis-caching",
                "description": "Cache hot paths with Redis.",
                "category": "database",
                "tags": ["redis", "caching"],
                "languages": ["en"],
                "path": ".claude/skills/database/redis-caching",
            },
        ],
    }


def test_score_entry_matches_local_scoring() -> None:
    entry = _registry_payload()["skills"][0]
    # "agent" содержится в имени (50), описании через "agentic" (25) и теге "agents" (10)
    assert cli_mod.score_entry(entry, "agent") == 85
    # только в описании
    assert cli_mod.score_entry(entry, "reliable") == 25
    # "llm" в описании (25) и в теге "llm" (10)
    assert cli_mod.score_entry(entry, "llm") == 35
    assert cli_mod.score_entry(entry, "zzz-no-match") == 0


def test_search_remote_prints_registry_results(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cli_mod, "fetch_remote_catalog", lambda: _registry_payload()["skills"])
    result = CliRunner().invoke(cli, ["search", "agent", "--remote"])
    assert result.exit_code == 0, result.output
    out = _strip_ansi(result.output)
    assert "source: https://ssrjkk.github.io/agent-skills/skills_catalog.json" in out
    assert "agent-development" in out
    assert ".claude/skills/ai/agent-development" in out


def test_search_remote_respects_domain_and_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cli_mod, "fetch_remote_catalog", lambda: _registry_payload()["skills"])
    result = CliRunner().invoke(cli, ["search", "cache", "--remote", "--domain", "database"])
    assert result.exit_code == 0, result.output
    out = _strip_ansi(result.output)
    assert "redis-caching" in out
    assert "agent-development" not in out


def test_fetch_remote_catalog_raises_on_bad_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    class FakeUrlopen:
        def __init__(self, payload: bytes) -> None:
            self._payload = payload

        def __enter__(self) -> FakeUrlopen:
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def read(self) -> bytes:
            return self._payload

    monkeypatch.setattr(
        "urllib.request.urlopen", lambda _req, **_kwargs: FakeUrlopen(b'{"unexpected": true}')
    )
    with pytest.raises(click.ClickException, match="unexpected registry payload"):
        cli_mod.fetch_remote_catalog()


def test_fetch_remote_catalog_raises_on_network_error(monkeypatch: pytest.MonkeyPatch) -> None:
    import urllib.error

    def boom(_req: object, **_kwargs: object) -> None:
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr("urllib.request.urlopen", boom)
    with pytest.raises(click.ClickException, match="registry unavailable"):
        cli_mod.fetch_remote_catalog()
